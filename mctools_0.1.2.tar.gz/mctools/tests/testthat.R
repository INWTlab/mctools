library(mctools)
if (requireNamespace("testthat", quietly = TRUE)) {
  testthat::test_check("testthat")
}
